Note: this is an application intended for my own use in experiments. It is cumbersome and has only features that I needed so far. Ye be warned!

It could be called a prototype microtonal sequencer, although it was not initially intended to be one.

Good tones
----------
The application suggests tones that would cause minimal (locally minimal) sensory dissonance.
* choose which layers to include in calculation (the middle checkbox labelled "good")
* move the vertical cross hair to intersect tones of interest, or select a time range
* press 'g' to calculate
* if needed, press 'c' and 'C' to see the result on the vertical cross hair

Controls (hover mouse to show tooltips):
-----------------------------------------
At the bottom edge, left to right:
* open score
* save score as
* horizontal zoom
* playback
* calculate with combination tones

At the right edge, top to bottom, left to right:
* vertical zoom
* show textual annotations (if they were in the score)
* radiogroup: switch the grid between 1/12/48/53 edo
* snap to pitch grid
* snap to time grid
* six layers (instruments):
- radiobutton to select layer for entry
- combo to select playback instrument
- checkboxes: show/hide, select for calculation, select for playback

Mouse:
Click-drag in a free space: select of time range (aplies only to good tones calculation). Click to clear selection.
Drag tones, adjust their duration.
Ctrl-click and drag: enter tone in a layer

Keyboard (when mouse is over the piano roll):
c: switches the cross hairs (none, both, one, the other)
C: switches the vertical hair (just intervals, good tones, plain)
g: runs good tones calculation
p: puts a stack of calculated good tones in the selected layer (badly designed feature)
space: starts/stops playback

Undo
----
None whatsoever.

Score files
-----------
CSV format. Some example files are included.

Getting started:
----------------
* Start SuperCollider, boot the server.
* Run the application: java -jar notes.jar
  Requires Java 6 SE.
  Open a score file. Good luck.

Send me your comments and questions, please. Feel free to pass the files on.

Ian Burleigh
http://jbnotes.info
http://www.linkedin.com/in/burleigh
