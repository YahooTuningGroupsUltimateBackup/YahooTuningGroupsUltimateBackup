//#define _WIN_OS				// comment this line when compiling under Linux

#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>
#ifdef _WIN_OS
	#include <direct.h>		// required for file operations (Windows)
#else
	#include <sys/stat.h>	// required for file operations (Linux)
#endif

using namespace std;

string subfolder = "";


bool is_symmetrical(vector<int> &scale, int edo) {
	int size = scale.size();
	for (int i=0; i<size; i++) {	// try scales from all roots
		bool failed = false;
		for (int j=1; j<scale.size(); j++)
			if (edo - scale[size-j] != (edo + scale[(j+i) % size] - scale[i]) % edo) {
				failed = true;
				break;
			}
		if (!failed)
			return true;
	}
	return false;
}


bool translate(vector<int> &src_scale, vector<int> &dst_scale, int src_edo, int dst_edo, bool rnd_up, bool out_text) {
	int size = src_scale.size();
	if (src_edo < 1 || dst_edo < 1 || size != dst_scale.size())
		return false;

	for (int x = 0; x < size; x++)
		if (rnd_up)
			dst_scale[x] = (int)floor( dst_edo * src_scale[x]/(double)src_edo + 0.5 );
		else
			dst_scale[x] = (int)ceil( dst_edo * src_scale[x]/(double)src_edo - 0.5 );

	if (out_text) {
		for (int x = 0; x < size; x++)
			cout << dst_scale[x] << " " << 1200 * dst_scale[x] / (double)dst_edo << " cents" << endl;
		cout << dst_edo << " 1200 cents" << endl << endl;
	}

	return true;
}


bool save_file(string &outfilename, vector<int> &scale, int edo) {
	#ifdef _WIN_OS
		_mkdir(subfolder.c_str());
	#else
		mkdir(subfolder.c_str(), 0777);
	#endif
	ofstream file((subfolder + outfilename).c_str(), ios::binary);	// open for text mode
	if (!file.is_open())
		return false;
	file.precision(5);

	int size = scale.size();

	file << "! " << outfilename << "\r\n";
	file << "!\r\n\r\n " << size << "\r\n!\r\n";
	for (int x = 1; x < size; x++)
		file << " " << fixed << 1200 * scale[x] / (double)edo << "\r\n";
	file << " 2/1\r\n";

	file.close();

	return true;
}


bool mass_translate(/*string &base_name,*/ int src_edo, int min_dst_edo, int max_dst_edo, bool rnd_up) {
	if (src_edo < 1 || min_dst_edo < src_edo || max_dst_edo < min_dst_edo)
		return false;
	
	vector<int> src_scale(src_edo, 0), dst_scale(src_edo, 0);
	
	// init source scale
	for (int i = 0; i < src_edo; i++)
		src_scale[i] = i;

	stringstream ss; ss << src_edo;
	string base_name = ss.str() + "edo_to_";
	ss.str(""); ss << min_dst_edo;

	// generate destination scales
	for (int N = min_dst_edo; N <= max_dst_edo; N++) {
			stringstream ss_dst; ss_dst << N;
			string filename = base_name + ss_dst.str() + "edo.scl";
		if (!translate(src_scale, dst_scale, src_edo, N, rnd_up, false))
			return false;
		if (!save_file(filename, dst_scale, N))
			return false;
	}

	return true;
}


int get_int(int min, int max) {
	if (min > max)
		return -1;

	string input = "";
	int choice = 0;
	stringstream s_min, s_max; s_min << min; s_max << max;
	while (true) {
		getline(cin, input);
		stringstream inputStream(input);
		if (inputStream >> choice && choice >= min && choice <= max)
			break;
		cout << "Input not accepted! Please input a number between " << s_min.str() << " and " << s_max.str() <<"!" << endl;
	}
	return choice;
}


int main(int argc, const char *argv[]) {
	// OS-dependent file stuff...
	char cwd[256];
	#ifdef _WIN_OS
		_getcwd(cwd, 255);
		char slash = '\\';
		subfolder = "scl\\";
	#else
		getcwd(cwd, 255);
		char slash = '/';
		subfolder = "scl/";
	#endif

	bool next = false;
	bool rnd_up = true;

	// main loop
	while(true) {

		// main menu
		cout << "What do you want to do" << (next ? " next" : "") << "?" << endl << endl;
		cout << "(1) Translate a single EDO into a range of other EDOs" << endl;
		cout << "(2) Step-by-step translation mode" << endl;
		cout << "    (allows for translation chains like 12 -> 31 -> 53 -> 200)" << endl;
		cout << "(3) Switch prefered rounding direction (currently: " << (rnd_up ? "up)" : "down)") << endl;
		cout << "(4) Quit" << endl << endl;
		
		// read user input
		int choice = get_int(1, 4);
		cout << endl;

		if (choice == 4)
			return 0;
		next = true;

		if (choice == 1) {
			// mass translation mode
			cout << "Please enter the EDO that should be translated!" << endl;
			int src_edo = get_int(2, 32766);
			stringstream s_src_edo; s_src_edo << src_edo;
			cout << "Please enter the smallest EDO to which " << s_src_edo.str() << "-EDO should be translated!" << endl;
			int min_dst_edo = get_int(src_edo + 1, 32767);
			cout << "Please enter the largest EDO to which " << s_src_edo.str() << "-EDO should be translated!" << endl;
			int max_dst_edo = get_int(min_dst_edo, 32767);
			cout << endl;

			if (!mass_translate(src_edo, min_dst_edo, max_dst_edo, rnd_up)) {
				cout << "Translation failed for unknown reasons! Press <enter> to quit...";
				cin.get();
				return -1;
			}
			cout << "File" << (max_dst_edo - min_dst_edo > 0 ? "s" : "") <<" successfully saved to \"" << cwd << slash << subfolder << "\"!" << endl << endl;
		} else if (choice == 2) {
			// chain translation mode
			cout << "Please enter the EDO that should be translated!" << endl;
			int cur_edo = get_int(2, 32766);
			vector<int> scale(cur_edo, 0);
			for (int i = 0; i < cur_edo; i++)
				scale[i] = i;
			vector<int> chain(1, cur_edo);

			// chain translation loop
			bool do_continue = true;
			int sub_choice = 1;
			while(do_continue) {
				if (sub_choice == 1) {
					// continue translation
					cout << "Please enter the next EDO to which the current scale should be translated!" << endl;
					int dst_edo = get_int(cur_edo + 1, 32767);
					cout << endl;

					chain.push_back(dst_edo);
					cout << chain[0];
					for (int i=1; i < chain.size(); i++)
						cout << " -> " << chain[i];
					cout << endl << endl;
					if (!translate(scale, scale, cur_edo, dst_edo, rnd_up, true)) {
						cout << "Translation failed for unknown reasons! Press <enter> to quit...";
						cin.get();
						return -1;
					}
					cur_edo = dst_edo;
				} else if (sub_choice == 2) {
					// save scale in .scl file

					// create file name
					stringstream ss; ss << chain[0];
					string basefilename = ss.str() + "edo_to_";
					ss.str("");
					if (chain.size() == 3) {
						ss << chain[1];
						basefilename += ss.str() + "edo_to_";
						ss.str("");
					} else if (chain.size() > 3)
						basefilename += "chain_to_";
					ss << chain[chain.size()-1];
					basefilename += ss.str() + "edo";

					string outfilename = basefilename + ".scl";
					if (!save_file(outfilename, scale, cur_edo)) {
						cout << "File could not be saved! Press <enter> to quit...";
						cin.get();
						return -1;
					}
					bool sym = is_symmetrical(scale, cur_edo);
					if (!sym) {
						int size = scale.size();
						vector<int> mirror_scale(size, 0);
						for (int i=0; i<size; i++)
							mirror_scale[i] = (cur_edo - scale[(size-i) % size]) % cur_edo;
						outfilename = basefilename + "M.scl";
						if (!save_file(outfilename, mirror_scale, cur_edo)) {
							cout << "File could not be saved! Press <enter> to quit...";
							cin.get();
							return -1;
						}
					}
					cout << "File" << (sym ? "" : "s") << " successfully saved to \"" << cwd << slash << subfolder << "\"!" << endl << endl;
				} else if (sub_choice == 3) {
					// switch prefered rounding direction
					rnd_up = !rnd_up;
				} else if (sub_choice == 4) {
					// return to main menu
					break;
				} else if (sub_choice == 5) {
					// quit
					return 0;
				}
				// chain translation menu
				cout << "What do you want to do next?" << endl << endl;
				if (cur_edo < 32767)
					cout << "(1) Translate current scale into another EDO" << endl;
				cout << "(2) Save current scale in .scl file" << endl;
				cout << "(3) Switch prefered rounding direction (currently: " << (rnd_up ? "up)" : "down)") << endl;
				cout << "(4) Return to main menu" << endl;
				cout << "(5) Quit" << endl << endl;
		
				// read user input
				sub_choice = get_int(cur_edo < 32767 ? 1 : 2, 5);
				cout << endl;
			}
		} else if (choice == 3) {
			// switch prefered rounding direction
			rnd_up = !rnd_up;
		}
	}
}